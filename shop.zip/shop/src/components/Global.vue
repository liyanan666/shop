<script type="text/javascript">
	var host = '';
	if(location.host.indexOf('localhost')>=0){
		
		host = 'http://127.0.0.1:3000';
	}else{
		host = '';

	}
	export default {
	  host
	}
</script>